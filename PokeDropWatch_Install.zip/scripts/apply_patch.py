#!/usr/bin/env python3
"""Safely install a ZIP whose paths are relative to the repository root."""
from __future__ import annotations

import argparse
import stat
import zipfile
from pathlib import Path, PurePosixPath

MAX_FILES = 1000
MAX_UNCOMPRESSED = 50 * 1024 * 1024
BLOCKED_TOP_LEVEL = {".git", "updates"}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive")
    args = parser.parse_args()
    archive = Path(args.archive)
    root = Path.cwd().resolve()
    if not archive.is_file() or not zipfile.is_zipfile(archive):
        raise SystemExit(f"Not a valid ZIP file: {archive}")

    with zipfile.ZipFile(archive) as zf:
        entries = [entry for entry in zf.infolist() if not entry.is_dir()]
        if len(entries) > MAX_FILES:
            raise SystemExit(f"Patch rejected: more than {MAX_FILES} files.")
        expanded = sum(entry.file_size for entry in entries)
        if expanded > MAX_UNCOMPRESSED:
            raise SystemExit("Patch rejected: expanded size exceeds 50 MB.")

        plan = []
        for entry in entries:
            raw = entry.filename.replace("\\", "/")
            rel = PurePosixPath(raw)
            if rel.is_absolute() or not rel.parts or any(part in {"", ".", ".."} for part in rel.parts):
                raise SystemExit(f"Unsafe path in ZIP: {entry.filename}")
            if rel.parts[0] in BLOCKED_TOP_LEVEL:
                raise SystemExit(f"Patch may not write into {rel.parts[0]}/")
            # Workflow files cannot be changed through this token-only patch process.
            if len(rel.parts) >= 3 and rel.parts[:2] == (".github", "workflows"):
                raise SystemExit("Patch may not modify .github/workflows; upload workflow changes manually.")
            mode = (entry.external_attr >> 16) & 0xFFFF
            if stat.S_ISLNK(mode):
                raise SystemExit(f"Symlinks are not accepted in ZIP patches: {entry.filename}")
            destination = (root / Path(*rel.parts)).resolve()
            if root not in destination.parents:
                raise SystemExit(f"Unsafe destination: {entry.filename}")
            plan.append((entry, destination))

        for entry, destination in plan:
            destination.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(entry, "r") as source, destination.open("wb") as target:
                while chunk := source.read(1024 * 1024):
                    target.write(chunk)
            print(f"Installed {destination.relative_to(root)}")

    print(f"Applied {len(plan)} file(s) from {archive.name}.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
