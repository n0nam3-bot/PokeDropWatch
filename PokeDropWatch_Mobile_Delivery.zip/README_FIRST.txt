POKEDROP WATCH — MOBILE DOWNLOAD BUNDLE

This bundle contains:
  pokedrop-watch.yml       The permanent GitHub Actions workflow
  PokeDropWatch_Install.zip  The complete application files

IMPORTANT: GitHub cannot run a workflow that is only inside an uploaded ZIP.
There is one unavoidable one-time setup step before ZIP uploads can auto-install:

1. In your GitHub repository, choose Add file > Create new file.
2. Enter this exact path as the filename:
   .github/workflows/pokedrop-watch.yml
3. Open the pokedrop-watch.yml file from this bundle, copy its entire contents,
   paste them into the GitHub editor, and commit to the main branch.
4. In Settings > Actions > General > Workflow permissions, enable
   Read and write permissions and save.
5. Upload this entire downloaded bundle ZIP to the repository ROOT.
   The workflow will find the nested PokeDropWatch_Install.zip, extract the
   app into docs/, monitor/, config/, scripts/, and tests/, then commit it.

After installation, future update ZIPs can be uploaded to the repository root
or updates/ folder. The workflow automatically applies them and removes the
uploaded ZIP after a successful run.

To publish the dashboard: Settings > Pages > Build and deployment > Deploy
from a branch > main > /docs.

Email alerts require repository Actions secrets:
  SMTP_HOST=smtp.gmail.com
  SMTP_PORT=587
  SMTP_USERNAME=your Gmail address
  SMTP_APP_PASSWORD=your Google App Password
  ALERT_EMAIL=where alerts should be sent

GitHub's scheduled workflows run approximately every 15 minutes, but actual
start times can be delayed by GitHub. Retailers may block automated scans or
change page markup, so source status must be checked in the dashboard.
