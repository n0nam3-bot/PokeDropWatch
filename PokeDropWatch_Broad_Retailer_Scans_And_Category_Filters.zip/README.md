# PokéDrop Watch

A fan-made Pokémon product discovery and restock monitor. The public site shows products and scan health; GitHub Actions checks configured retailer pages on a schedule; verified subscribers can apply for email alerts; and an administrator approves subscribers before delivery starts.

**Public website:** https://n0nam3-bot.github.io/PokeDropWatch/  
**Administrator:** https://n0nam3-bot.github.io/PokeDropWatch/admin.html  
**Repository:** https://github.com/n0nam3-bot/PokeDropWatch

## What it does

- Checks each configured primary retailer route on every 15-minute scan.
- Uses broad Pokémon searches for Target, Walmart, and Amazon; categories are inferred from product data and filtered on the website.
- Keeps Pokémon Center's known TCG and plush pages separate because a verified single broad catalog route is not configured. Best Buy and GameStop currently cover their configured Pokémon TCG pages.
- Tries a backup only when the primary route fails, is blocked, or returns no usable entries.
- Preserves product history when older split category routes are consolidated.
- Offers search, exact-title, item-category, retailer and alert-type filters.
- Sends email notifications for verified stock transitions, price drops/changes and Pokémon news to approved subscribers.
- Provides a private administrator portal to approve, reject, suspend and remove subscriber records.

## Services and configuration required

| Service | Why it is used | Owner configuration |
|---|---|---|
| GitHub Pages | Hosts the public website | Publish branch `main`, folder `/docs` |
| GitHub Actions | Scheduled scans and product-alert email | Install `.github/workflows/pokedrop-watch.yml` once; configure repository secrets/variables |
| Firebase Firestore | Private subscriber database | Create Firestore Native database and service-account access |
| Google Apps Script | Verification codes and private administrator API | Deploy web app as `pokedropwatch.notify@gmail.com`, then set its `/exec` URL in `docs/subscription-backend-config.js` |
| Gmail | Verification and product notification sender | Configure Apps Script and Gmail App Password for SMTP alerts |

The current admin login is handled by the Apps Script backend, not Firebase Authentication. No Firebase email-link sign-in or password-reset action link is used. No Google Sheet is required. Free service quotas apply; email and monitoring are not unlimited.

## Owner setup

Follow [`owner-docs/SETUP.md`](owner-docs/SETUP.md) for exact links, menu paths, property names, secrets, and step-by-step setup. The detailed owner instructions live outside `/docs`, so they are not part of the public GitHub Pages site.

## Monitoring status

The dashboard groups source status by retailer. Backups are tried only when the primary route fails, is blocked, or returns no usable entries. Retailers that do not expose a verified broad route keep only the necessary category pages.

## Development

- Source configuration: `config/sources.json`
- Monitor: `monitor/engine.py`, `monitor/engine_recovery_patch.py`, `monitor/broad_source_patch.py`, `monitor/run.py`
- Public website: `docs/index.html`, `docs/styles.css`, `docs/app.js`, `docs/source-groups.js`
- Subscriber/admin bridge: `backend/apps-script/`
- Firestore client rules: `firebase/firestore.rules`
- Roadmap: `docs/ROADMAP.md`
- Changelog: `docs/CHANGELOG.md`
- Change/configuration reference: `docs/CONFIGURATION_AND_CHANGE_GUIDE.md`

Run tests with `python -m unittest discover -s tests -v`.

PokéDrop Watch is a fan-made tracker and is not affiliated with Nintendo, The Pokémon Company, Pokémon Center, or any retailer.
